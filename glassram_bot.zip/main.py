import telebot
import json
from utils import load_products
import os

TOKEN = os.getenv("TOKEN")  # توکن از محیط خوانده می‌شود
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "👋 خوش آمدید به ربات کاشی گلسرام!
برای دیدن محصولات، دستور /products را وارد کنید.")

@bot.message_handler(commands=['products'])
def send_products(message):
    products = load_products()
    if not products:
        bot.reply_to(message, "محصولی یافت نشد.")
        return
    for p in products:
        caption = f"📌 {p['name']}
💵 قیمت: {p['price']} تومان
📦 موجودی: {p['stock']} عدد"
        with open(p['image'], 'rb') as photo:
            bot.send_photo(message.chat.id, photo, caption=caption)

bot.infinity_polling()
